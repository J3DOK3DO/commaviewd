# CommaView runtime v0.0.58-beta — StarPilot C6-12 compatibility build

This is a C6-12-specific beta release of the CommaView device runtime,
based on the known-working v0.0.57-beta CommaView bundle and the 8e4fc8b
StarPilot source branch. It is NOT the upstream CommaView v0.0.58-alpha
feature set, and does NOT include a new Android APK.

## Fixed
- Encode-data subscription for StarPilot C6-12 (roadEncodeData and
  driverEncodeData instead of narrowRoadEncodeData and cabinEncodeData).
- Includes C6-12 message-queue impl_zmq.cc at build/link time.
- Preserves $ORIGIN/lib lookup for the bundled Cap'n Proto libraries.
- Keeps ports 8200-8203, 5002, frame protocol, and existing UI integration.

## Validation / known limitations
- The binary in this release is byte-identical to the currently running
  C6-12 compatibility executable confirmed working in an initial Android
  Live View test by the vehicle owner on October 11, 2026.
- C6-12 interface guard and video build contract passed; isolated ARM64
  runtime opened all expected ports; on-device bridge and control healthy.
- Long-duration driving-session video reliability and all phone/network
  combinations have NOT yet been established. The brief success does not
  prove every reconnecting cause has been eliminated.
- Does not change openpilot, Panda, driving algorithms or Android app.
- NOT a universal Sunnypilot runtime; use official channel for normal
  Sunnypilot.

## Assets
- commaview-comma-v0.0.58-beta.tar.gz: full device bundle, including
  the exact tested ARM64 bridge, installer/scripts, libs and version.
- Matching .sha256 archive-integrity manifest.
- provenance.json documenting source and validation scope.
- c612-video-compat-source.patch showing the source/build changes.

Install only while offroad/parked and preserve a runtime rollback.
Set COMMAVIEWD_RELEASE_REPO=J3DOK3DO/commaviewd for this fork, not
the official CommaView release origin.
